package com.example.ticketingapp;

import java.io.Serializable;

public class User implements Serializable {

    private String id;
    private String timeEnter;
    private String placeEnter;
    private String timeExit;
    private String placeExit;
    private String cost;

    public User(String id, String timeEnter, String placeEnter, String timeExit, String placeExit, String cost)
    {
        this.id = id;
        this.timeEnter = timeEnter;
        this.placeEnter = placeEnter;
        this.timeExit = timeExit;
        this.placeExit = placeExit;
        this.cost = cost;
    }

    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }

    public String getTimeEnter() {
        return timeEnter;
    }
    public void setTimeEnter(String timeEnter) {
        this.timeEnter = timeEnter;
    }

    public String getPlaceEnter() {
        return placeEnter;
    }

    public void setPlaceEnter(String placeEnter) {
        this.placeEnter = placeEnter;
    }

    public String getTimeExit() {
        return timeExit;
    }

    public void setTimeExit(String timeExit) {
        this.timeExit = timeExit;
    }

    public String getPlaceExit() {
        return placeExit;
    }

    public void setPlaceExit(String placeExit) {
        this.placeExit = placeExit;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }
}
