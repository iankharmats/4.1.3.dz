package com.example.ticketingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private EditText idIn;
    private EditText timeEnterIn;
    private EditText placeEnterIn;
    private EditText timeExitIn;
    private EditText placeExitIn;
    private EditText costIn;
    private Button button;


    private String id;
    private String timeEnter;
    private String placeEnter;
    private String timeExit;
    private String placeExit;
    private String cost;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        idIn = findViewById(R.id.idIn);
        timeEnterIn = findViewById(R.id.timeEnterIn);
        placeEnterIn = findViewById(R.id.placeEnterIn);
        timeExitIn = findViewById(R.id.timeExitIn);
        placeExitIn = findViewById(R.id.placeExitIn);
        costIn = findViewById(R.id.costIn);
        button = findViewById(R.id.button);

        button.setOnClickListener(listener);
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            id = idIn.getText().toString();
            timeEnter = timeEnterIn.getText().toString();
            placeEnter = placeEnterIn.getText().toString();
            timeExit = timeExitIn.getText().toString();
            placeExit = placeExitIn.getText().toString();
            cost = costIn.getText().toString();

            User user = new User(id, timeEnter, placeEnter, timeExit, placeExit, cost);

            Intent intent = new Intent(getApplicationContext(), SecondActivity.class);

            intent.putExtra(User.class.getSimpleName(), user);

            startActivity(intent);
        }
    };
}