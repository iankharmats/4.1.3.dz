package com.example.ticketingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    private TextView dataMainActivity;
    private Button button;

    private User user;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        dataMainActivity = findViewById(R.id.dataUser);
        button = findViewById(R.id.button);

        Bundle bundleIntent = getIntent().getExtras();

        if (bundleIntent != null) {
            user = (User) bundleIntent.getSerializable(User.class.getSimpleName());
            dataMainActivity.setText("ID пользователя:\n" + user.getId() + "\nВремя отправления:\n" + user.getTimeEnter() +
                    "\nМесто отправления:\n" + user.getPlaceEnter() + "\nВремя прибытия:\n" + user.getTimeExit() +
                    "\nМесто прибытия:\n" + user.getPlaceExit() + "\nСтоимость билета:\n" + user.getCost());
        }

        button.setOnClickListener(listener);
    }

    private View.OnClickListener listener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
        }
    };
}